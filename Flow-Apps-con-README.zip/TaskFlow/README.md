# TaskFlow

Gestor de tareas con agenda, proyectos, prioridades y estadísticas de productividad.

App Android nativa hecha con **Kotlin + Jetpack Compose + Material 3**, con estilo de cristal (glassmorphism).

## Funciones

- **Hoy:** tareas atrasadas y las de hoy, con contador de completadas.
- **Tareas:** filtro Pendientes / Completadas / Todas. Cada tarea tiene prioridad (Baja, Media, Alta), categoría (Personal, Trabajo, Estudio, Hogar, Salud), proyecto y fecha límite.
- **Agenda:** tareas organizadas por día.
- **Proyectos:** crea proyectos y mira cuántas tareas llevas completadas en cada uno.
- **Datos:** completadas en los últimos 7 días, pendientes por prioridad y tareas por categoría.
- **Recordatorios:** notificación a las 9:00 del día de vencimiento (opcional por tarea).
- Los datos se guardan solo en el dispositivo. Sin cuenta ni conexión a Internet.

## Datos técnicos

| | |
|---|---|
| Paquete | `com.flowapps.taskflow` |
| Android mínimo | 8.0 (API 26) |
| Versión | 1.0 |
| Permisos | Notificaciones (`POST_NOTIFICATIONS`) |
| Almacenamiento | SharedPreferences (JSON) |

## Limitaciones conocidas

- Los recordatorios no se reprograman al reiniciar el teléfono.

## Cómo compilarla

La app se compila en GitHub Actions, no hace falta Android Studio.

1. Asegúrate de que el workflow esté en `.github/workflows/build-taskflow.yml` (está en `workflows-para-mover/` y hay que moverlo).
2. Ve a la pestaña **Actions**, elige **Build TaskFlow** y toca **Run workflow**.
3. Cuando termine (punto verde), entra a la ejecución y baja a **Artifacts**.
4. Descarga `TaskFlow-apk`, descomprime el zip e instala `TaskFlow.apk` en tu teléfono (Android te pedirá permitir "Instalar apps desconocidas").

Es un APK de **depuración**, no está firmado para Play Store.

## Compilar en tu equipo (opcional)

Requiere JDK 17, Android SDK y Gradle 8.7:

```bash
cd TaskFlow
gradle assembleDebug
# APK en app/build/outputs/apk/debug/app-debug.apk
```

## Iconos propios

Mira [`PNG-ICONOS.md`](PNG-ICONOS.md) para cambiar el icono y el logotipo por tus PNG.

## Estado

> El código **no se ha compilado nunca**. El primer build en GitHub Actions lo comprobará. Si falla, copia el error del log para corregirlo.
