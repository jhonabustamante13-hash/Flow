package com.flowapps.taskflow.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import com.flowapps.taskflow.Reminders

data class Task(
    val id: Long, val title: String, val priority: Int = 1, val category: String = "Personal", val project: String = "",
    val due: String = "", val done: Boolean = false, val remind: Boolean = false, val doneAt: Long = 0L
)

object TaskStore {
    val tasks = mutableStateListOf<Task>()
    val projects = mutableStateListOf<String>()
    val categories = listOf("Personal", "Trabajo", "Estudio", "Hogar", "Salud")

    fun load() {
        tasks.clear(); projects.clear()
        runCatching {
            val a = JSONArray(Prefs.getString("tasks", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                tasks.add(Task(o.getLong("id"), o.getString("t"), o.getInt("pr"), o.getString("c"), o.getString("p"), o.getString("d"), o.getBoolean("dn"), o.getBoolean("r"), o.getLong("da")))
            }
        }
        projects.addAll(Prefs.getString("projects", "").split("|").filter { it.isNotBlank() })
    }

    private fun save() {
        val a = JSONArray()
        tasks.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("pr", it.priority).put("c", it.category).put("p", it.project).put("d", it.due).put("dn", it.done).put("r", it.remind).put("da", it.doneAt)) }
        Prefs.putString("tasks", a.toString())
        Prefs.putString("projects", projects.joinToString("|"))
    }

    fun upsert(ctx: Context, t: Task) {
        val i = tasks.indexOfFirst { it.id == t.id }
        if (i >= 0) tasks[i] = t else tasks.add(t)
        save()
        Reminders.schedule(ctx, t)
    }

    fun delete(ctx: Context, id: Long) {
        tasks.removeAll { it.id == id }
        save()
        Reminders.cancel(ctx, id)
    }

    fun addProject(name: String) { if (name.isNotBlank() && name !in projects) { projects.add(name.trim()); save() } }

    fun deleteProject(name: String) {
        projects.remove(name)
        for (i in tasks.indices) if (tasks[i].project == name) tasks[i] = tasks[i].copy(project = "")
        save()
    }
}
