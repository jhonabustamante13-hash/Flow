# EventFlow, WordFlow, GalleryX y TaskFlow

Cada carpeta es una app independiente. Los workflows estan en workflows-para-mover/.
Mueve cada uno a .github/workflows/ (lapiz > cambiar nombre del archivo a .github/workflows/NOMBRE.yml > Commit).

Aviso: este codigo NO se ha compilado nunca. Si el build falla, pega el log del error.
Pendiente: EventFlow no tiene vista de calendario mensual (solo lista por fecha);
TaskFlow no reprograma recordatorios tras reiniciar el telefono; GalleryX no borra en Android 9 o menor sin permiso extra.
