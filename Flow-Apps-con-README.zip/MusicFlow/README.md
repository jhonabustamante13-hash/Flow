# MusicFlow

Reproductor de música local con cola, favoritas, álbumes y letras.

App Android nativa hecha con **Kotlin + Jetpack Compose + Material 3** y **Media3 (ExoPlayer)**.

## Funciones

- **Canciones:** toda la música del teléfono, con búsqueda por título, artista o álbum.
- **Favoritas**, **Álbumes** y **Cola.**
- **Reproductor:** play/pausa, anterior/siguiente, aleatorio y repetir (apagado, todas, una).
- **Vista Portada / Letra:** pega la letra o importa un archivo `.lrc` (sincronizada) o `.txt`.
- **Reproducción en segundo plano**, con notificación y controles multimedia del sistema.
- Ignora audios de menos de 30 segundos (tonos, notas de voz).
- Tema claro u oscuro según el sistema.
- Sin cuenta ni conexión a Internet.

## Datos técnicos

| | |
|---|---|
| Paquete | `com.flowapps.musicflow` |
| Android mínimo | 8.0 (API 26) |
| Versión | 1.0 |
| Permisos | Audio (`READ_MEDIA_AUDIO`; almacenamiento en Android 12 o menor), servicio en primer plano y notificaciones |
| Librerías | Media3 (ExoPlayer, Session), Guava |

## Cómo compilarla

La app se compila en GitHub Actions, no hace falta Android Studio.

1. Asegúrate de que el workflow esté en `.github/workflows/build-musicflow.yml` (está en `workflows-para-mover/` y hay que moverlo).
2. Ve a la pestaña **Actions**, elige **Build MusicFlow** y toca **Run workflow**.
3. Cuando termine (punto verde), entra a la ejecución y baja a **Artifacts**.
4. Descarga `MusicFlow-apk`, descomprime el zip e instala `MusicFlow.apk` en tu teléfono (Android te pedirá permitir "Instalar apps desconocidas").

Es un APK de **depuración**, no está firmado para Play Store.

## Compilar en tu equipo (opcional)

Requiere JDK 17, Android SDK y Gradle 8.7:

```bash
cd MusicFlow
gradle assembleDebug
# APK en app/build/outputs/apk/debug/app-debug.apk
```

## Iconos propios

Mira [`PNG-ICONOS.md`](PNG-ICONOS.md) para cambiar el icono y el logotipo por tus PNG.

## Estado

> El código **no se ha compilado nunca**. El primer build en GitHub Actions lo comprobará. Si falla, copia el error del log para corregirlo.
