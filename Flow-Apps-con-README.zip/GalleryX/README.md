# GalleryX

Galería de fotos y vídeos del dispositivo con álbumes, favoritos y visor a pantalla completa.

App Android nativa hecha con **Kotlin + Jetpack Compose + Material 3**, con estilo de cristal (glassmorphism).

## Funciones

- **Fotos:** cuadrícula de 3 columnas con fotos y vídeos, de más reciente a más antigua.
- **Álbumes:** agrupados por carpeta del dispositivo.
- **Favoritos.**
- **Visor:** desliza entre archivos, reproduce vídeos, mira la información del archivo, comparte, marca favorito o elimina.
- **Selección múltiple:** mantén pulsado para elegir varios y compartirlos, marcarlos o borrarlos.
- **Ajustes:** tema Sistema / Claro / Oscuro.
- **Privacidad:** solo lee los archivos del dispositivo. No sube nada a Internet.

## Datos técnicos

| | |
|---|---|
| Paquete | `com.flowapps.galleryx` |
| Android mínimo | 8.0 (API 26) |
| Versión | 1.0 |
| Permisos | Fotos y vídeos (`READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`); almacenamiento en Android 12 o menor |
| Librerías | Coil (imágenes y miniaturas de vídeo), Media3 ExoPlayer |

## Limitaciones conocidas

- En Android 10 o menor, el borrado puede fallar sin un permiso extra. En Android 11 o superior pide confirmación al sistema.

## Cómo compilarla

La app se compila en GitHub Actions, no hace falta Android Studio.

1. Asegúrate de que el workflow esté en `.github/workflows/build-galleryx.yml` (está en `workflows-para-mover/` y hay que moverlo).
2. Ve a la pestaña **Actions**, elige **Build GalleryX** y toca **Run workflow**.
3. Cuando termine (punto verde), entra a la ejecución y baja a **Artifacts**.
4. Descarga `GalleryX-apk`, descomprime el zip e instala `GalleryX.apk` en tu teléfono (Android te pedirá permitir "Instalar apps desconocidas").

Es un APK de **depuración**, no está firmado para Play Store.

## Compilar en tu equipo (opcional)

Requiere JDK 17, Android SDK y Gradle 8.7:

```bash
cd GalleryX
gradle assembleDebug
# APK en app/build/outputs/apk/debug/app-debug.apk
```

## Iconos propios

Mira [`PNG-ICONOS.md`](PNG-ICONOS.md) para cambiar el icono y el logotipo por tus PNG.

## Estado

> El código **no se ha compilado nunca**. El primer build en GitHub Actions lo comprobará. Si falla, copia el error del log para corregirlo.
