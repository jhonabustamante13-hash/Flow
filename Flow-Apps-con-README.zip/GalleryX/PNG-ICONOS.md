# Iconos PNG propios de GalleryX

Por ahora la app usa un icono vectorial propio (no es tu PNG).
Para usar tus PNG:

1. Borra estos dos archivos:
   - app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml
   - app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml
2. Sube tus PNG con estos nombres exactos a:
   - app/src/main/res/mipmap-xxxhdpi/ic_launcher.png (192x192)
   - app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png (192x192)
3. Logotipo para usar dentro de la app: app/src/main/res/drawable-nodpi/logo.png
   (la pantalla de bienvenida usa por ahora la inicial del nombre).
