package com.flowapps.galleryx.ui

import androidx.compose.ui.graphics.Color

val GalleryDark = Look(listOf(Color(0xFF062B33), Color(0xFF0B4F5C), Color(0xFF0A6B63)), Color(0xFF14B8A6), Color(0xFFE9FFFC), 0.2f)
val GalleryLight = Look(listOf(Color(0xFFE0F7F5), Color(0xFFCDEFEF)), Color(0xFF0F8F86), Color(0xFF06323A), 0.55f)
