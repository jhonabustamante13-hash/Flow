package com.flowapps.galleryx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.flowapps.galleryx.data.*
import com.flowapps.galleryx.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        ThemeState.init()
        setContent { AppTheme(GalleryDark, GalleryLight) { GalleryApp() } }
    }
}
