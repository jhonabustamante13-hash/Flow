package com.flowapps.galleryx.data

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateListOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Media(
    val id: Long, val uri: Uri, val name: String, val date: Long, val video: Boolean,
    val bucket: String, val size: Long, val w: Int, val h: Int, val dur: Long
) {
    val key: String get() = (if (video) "v" else "i") + id
}

private fun Cursor.l(n: String): Long = getColumnIndex(n).let { if (it >= 0 && !isNull(it)) getLong(it) else 0L }
private fun Cursor.s(n: String): String = getColumnIndex(n).let { if (it >= 0 && !isNull(it)) getString(it) else "" }

object Gallery {
    val items = mutableStateListOf<Media>()
    val favs = mutableStateListOf<String>()

    suspend fun load(ctx: Context) {
        val out = withContext(Dispatchers.IO) {
            (query(ctx, false) + query(ctx, true)).sortedByDescending { it.date }
        }
        items.clear(); items.addAll(out)
        favs.clear(); favs.addAll(Prefs.getString("favs", "").split(",").filter { it.isNotBlank() })
    }

    private fun query(ctx: Context, video: Boolean): List<Media> {
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val cols = arrayOf("_id", "_display_name", "date_added", "_size", "width", "height", "bucket_display_name") + (if (video) arrayOf("duration") else emptyArray())
        val res = ArrayList<Media>()
        runCatching {
            ctx.contentResolver.query(base, cols, null, null, "date_added DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.l("_id")
                    res.add(
                        Media(
                            id, ContentUris.withAppendedId(base, id), c.s("_display_name"), c.l("date_added"), video,
                            c.s("bucket_display_name").ifBlank { "Otros" }, c.l("_size"), c.l("width").toInt(), c.l("height").toInt(),
                            if (video) c.l("duration") else 0L
                        )
                    )
                }
            }
        }
        return res
    }

    fun toggleFav(key: String) {
        if (favs.contains(key)) favs.remove(key) else favs.add(key)
        Prefs.putString("favs", favs.joinToString(","))
    }
}
