# CountDown

Cuentas regresivas para fechas importantes, con widget, notificación y foto de fondo.

App Android nativa hecha con **Kotlin + Jetpack Compose + Material 3**.

## Funciones

- **Crea cuentas regresivas** con título, fecha, hora y categoría (Cumpleaños, Viaje, Vacaciones, Boda, Evento, Personalizado).
- **Personaliza:** color y foto de fondo para cada una.
- **Favoritas:** filtro Todas / Favoritas. Marca una con la estrella.
- **Notificación** al llegar la fecha (opcional por cuenta).
- **Widget** de pantalla de inicio: muestra la favorita más próxima o, si no hay, la siguiente que llegue. Cambia de días a horas en el último día.
- Sin cuenta ni conexión a Internet.

## Datos técnicos

| | |
|---|---|
| Paquete | `com.flowapps.countdown` |
| Android mínimo | 8.0 (API 26) |
| Versión | 1.0 |
| Permisos | Notificaciones (`POST_NOTIFICATIONS`) |
| Almacenamiento | SharedPreferences (JSON); las fotos se copian a la carpeta interna de la app |

## Cómo compilarla

La app se compila en GitHub Actions, no hace falta Android Studio.

1. Asegúrate de que el workflow esté en `.github/workflows/build-countdown.yml` (está en `workflows-para-mover/` y hay que moverlo).
2. Ve a la pestaña **Actions**, elige **Build CountDown** y toca **Run workflow**.
3. Cuando termine (punto verde), entra a la ejecución y baja a **Artifacts**.
4. Descarga `CountDown-apk`, descomprime el zip e instala `CountDown.apk` en tu teléfono (Android te pedirá permitir "Instalar apps desconocidas").

Es un APK de **depuración**, no está firmado para Play Store.

## Compilar en tu equipo (opcional)

Requiere JDK 17, Android SDK y Gradle 8.7:

```bash
cd CountDown
gradle assembleDebug
# APK en app/build/outputs/apk/debug/app-debug.apk
```

## Iconos propios

Mira [`PNG-ICONOS.md`](PNG-ICONOS.md) para cambiar el icono y el logotipo por tus PNG.

## Estado

> El código **no se ha compilado nunca**. El primer build en GitHub Actions lo comprobará. Si falla, copia el error del log para corregirlo.
