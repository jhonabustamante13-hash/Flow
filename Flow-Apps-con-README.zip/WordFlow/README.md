# WordFlow

Diccionario en español que funciona sin conexión a Internet, con palabra del día, favoritas e historial.

App Android nativa hecha con **Kotlin + Jetpack Compose + Material 3**, con estilo de cristal (glassmorphism).

## Funciones

- **Buscar:** búsqueda que ignora tildes y mayúsculas, y muestra la palabra del día.
- **Detalle:** categoría gramatical, definición y ejemplo de uso. Se puede copiar o enviar.
- **Recientes** y **Favoritas.**
- **Ampliar el diccionario:** importa tus propias palabras desde Ajustes.
- Incluye 43 palabras de ejemplo (`app/src/main/assets/diccionario.json`).
- Sin cuenta ni conexión a Internet.

## Cómo añadir palabras

Desde **Ajustes > Importar archivo**, elige un `.json` o un `.txt`/`.csv`.

Formato JSON:

```json
[
  { "w": "efímero", "c": "adjetivo", "d": "Que dura poco tiempo.", "e": "Su fama fue efímera." }
]
```

Formato de texto, una palabra por línea (`palabra;categoría;definición;ejemplo`, el ejemplo es opcional):

```
sereno;adjetivo;Sin turbación ni agitación.;Mantuvo un semblante sereno.
```

Si una palabra ya existe, la tuya la reemplaza.

## Datos técnicos

| | |
|---|---|
| Paquete | `com.flowapps.wordflow` |
| Android mínimo | 8.0 (API 26) |
| Versión | 1.0 |
| Permisos | Ninguno |
| Almacenamiento | JSON en archivos internos + SharedPreferences |

## Cómo compilarla

La app se compila en GitHub Actions, no hace falta Android Studio.

1. Asegúrate de que el workflow esté en `.github/workflows/build-wordflow.yml` (está en `workflows-para-mover/` y hay que moverlo).
2. Ve a la pestaña **Actions**, elige **Build WordFlow** y toca **Run workflow**.
3. Cuando termine (punto verde), entra a la ejecución y baja a **Artifacts**.
4. Descarga `WordFlow-apk`, descomprime el zip e instala `WordFlow.apk` en tu teléfono (Android te pedirá permitir "Instalar apps desconocidas").

Es un APK de **depuración**, no está firmado para Play Store.

## Compilar en tu equipo (opcional)

Requiere JDK 17, Android SDK y Gradle 8.7:

```bash
cd WordFlow
gradle assembleDebug
# APK en app/build/outputs/apk/debug/app-debug.apk
```

## Iconos propios

Mira [`PNG-ICONOS.md`](PNG-ICONOS.md) para cambiar el icono y el logotipo por tus PNG.

## Estado

> El código **no se ha compilado nunca**. El primer build en GitHub Actions lo comprobará. Si falla, copia el error del log para corregirlo.
