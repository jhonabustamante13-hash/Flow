package com.flowapps.wordflow.ui

import androidx.compose.ui.graphics.Color

val WordDark = Look(listOf(Color(0xFF1E1A14), Color(0xFF2A2318)), Color(0xFFD9A066), Color(0xFFF3E9D7), 0.14f)
val WordLight = Look(listOf(Color(0xFFF7F0E1), Color(0xFFEFE3CB)), Color(0xFF8A4B2A), Color(0xFF2B2218), 0.6f)
