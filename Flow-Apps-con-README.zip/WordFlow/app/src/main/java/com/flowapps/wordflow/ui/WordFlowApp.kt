package com.flowapps.wordflow.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowapps.wordflow.data.*
import java.time.LocalDate

@Composable
fun WordFlowApp() {
    var splash by remember { mutableStateOf(true) }
    if (splash) Splash("WordFlow", "Tu diccionario sin conexión") { splash = false } else Shell()
}

@Composable
private fun Shell() {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    BackHandler(open != null) { open = null }
    GlassBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = tab to open,
                    transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(150)) },
                    label = "nav"
                ) { (t, o) ->
                    if (o != null) WordDetail(o) { open = null }
                    else when (t) {
                        0 -> SearchScreen { open = it }
                        1 -> ListScreen("Recientes", Dict.history.mapNotNull { Dict.find(it) }, "Aún no has consultado palabras.", { open = it }) { Dict.clearHistory() }
                        2 -> ListScreen("Favoritas", Dict.favs.mapNotNull { Dict.find(it) }, "Toca el corazón en una palabra para guardarla.", { open = it }, null)
                        else -> SettingsScreen("WordFlow") { ImportCard() }
                    }
                }
            }
            if (open == null) FloatingNav(
                listOf("Buscar" to Icons.Filled.Search, "Recientes" to Icons.Filled.Star, "Favoritas" to Icons.Filled.Favorite, "Ajustes" to Icons.Filled.Settings),
                tab, { tab = it }
            )
        }
    }
}

@Composable
private fun WordRow(e: Entry, onOpen: (String) -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(e.w) }) {
        Txt(e.w, 22.sp, true)
        Txt(e.c, 12.sp, alpha = 0.65f)
        Txt(e.d, 14.sp, alpha = 0.9f, maxLines = 2)
    }
}

@Composable
private fun SearchScreen(onOpen: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val res = remember(q, Dict.all.size) { Dict.search(q) }
    val daily = remember(Dict.all.size) { if (Dict.all.isEmpty()) null else Dict.all[LocalDate.now().dayOfYear % Dict.all.size] }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Txt("WordFlow", 34.sp, true, modifier = Modifier.padding(top = 8.dp))
        Txt("${Dict.all.size} palabras, sin conexión a Internet", 13.sp, alpha = 0.7f)
        Spacer(Modifier.height(12.dp))
        GlassCard(Modifier.fillMaxWidth()) { Field(q, { q = it }, "Buscar una palabra o definición") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            if (q.isBlank() && daily != null) {
                item { Txt("Palabra del día", 13.sp, true, alpha = 0.7f) }
                item { WordRow(daily, onOpen) }
                item { Txt("Todas las palabras", 13.sp, true, alpha = 0.7f) }
            }
            if (res.isEmpty()) item { Txt("No se encontró «$q». Puedes importar más palabras en Ajustes.", alpha = 0.8f) }
            items(res, key = { it.w }) { WordRow(it, onOpen) }
        }
    }
}

@Composable
private fun ListScreen(title: String, list: List<Entry>, empty: String, onOpen: (String) -> Unit, clear: (() -> Unit)?) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(title, 28.sp, true, modifier = Modifier.weight(1f))
            if (clear != null && list.isNotEmpty()) TextButton(onClick = clear) { Text("Borrar") }
        }
        Spacer(Modifier.height(10.dp))
        if (list.isEmpty()) Txt(empty, alpha = 0.8f)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(list, key = { it.w }) { WordRow(it, onOpen) } }
    }
}

@Composable
private fun WordDetail(w: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val look = LocalLook.current
    val e = Dict.find(w)
    if (e == null) { LaunchedEffect(Unit) { onBack() }; return }
    LaunchedEffect(w) { Dict.addHistory(e.w) }
    val fav = e.w in Dict.favs
    val text = "${e.w} (${e.c})\n${e.d}" + if (e.e.isNotBlank()) "\nEjemplo: ${e.e}" else ""
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Volver", tint = look.text) }
        Txt(e.w, 44.sp, true)
        Txt(e.c.uppercase(), 12.sp, true, alpha = 0.65f)
        GlassCard(Modifier.fillMaxWidth()) { Txt("Definición", 12.sp, true, alpha = 0.6f); Txt(e.d, 20.sp) }
        if (e.e.isNotBlank()) GlassCard(Modifier.fillMaxWidth()) { Txt("Ejemplo de uso", 12.sp, true, alpha = 0.6f); Txt("“${e.e}”", 18.sp) }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassButton(if (fav) "Quitar" else "Favorita", icon = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder) { Dict.toggleFav(e.w) }
            GlassButton("Copiar") { clip.setText(AnnotatedString(text)); Toast.makeText(ctx, "Copiado", Toast.LENGTH_SHORT).show() }
            GlassButton("Enviar", icon = Icons.Filled.Share) {
                val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                ctx.startActivity(Intent.createChooser(i, "Compartir definición"))
            }
        }
    }
}

@Composable
private fun ColumnScope.ImportCard() {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull() ?: ""
            val n = Dict.importText(ctx, txt)
            Toast.makeText(ctx, if (n > 0) "Se importaron $n palabras" else "No se pudo leer el archivo", Toast.LENGTH_LONG).show()
        }
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Txt("Ampliar el diccionario", bold = true)
        Txt("Importa un archivo .json o .txt/.csv con líneas: palabra;categoría;definición;ejemplo", 13.sp, alpha = 0.75f)
        Spacer(Modifier.height(10.dp))
        GlassButton("Importar archivo") { pick.launch(arrayOf("*/*")) }
    }
}
