# EventFlow

Organiza tus celebraciones: eventos con invitados, presupuesto, compras y preparativos en un solo lugar.

App Android nativa hecha con **Kotlin + Jetpack Compose + Material 3**, con estilo de cristal (glassmorphism).

## Funciones

- **Inicio:** tu próximo evento, días que faltan, progreso de preparativos y gasto total.
- **Eventos:** crea, edita y elimina eventos (nombre, fecha, hora, lugar y presupuesto).
- **Detalle de cada evento**, con cinco secciones:
  - *Resumen*: cuenta regresiva y estadísticas.
  - *Invitados*: lista con confirmación de asistencia.
  - *Presupuesto*: gastos, total gastado y restante.
  - *Compras*: artículos por comprar, con importe y marca de comprado.
  - *Preparativos*: tareas con barra de progreso.
- **Ajustes:** tema Sistema / Claro / Oscuro.
- Los datos se guardan solo en el dispositivo. Sin cuenta ni conexión a Internet.

## Datos técnicos

| | |
|---|---|
| Paquete | `com.flowapps.eventflow` |
| Android mínimo | 8.0 (API 26) |
| Versión | 1.0 |
| Permisos | Ninguno |
| Almacenamiento | SharedPreferences (JSON) |

## Limitaciones conocidas

- No tiene vista de calendario mensual, solo lista ordenada por fecha.

## Cómo compilarla

La app se compila en GitHub Actions, no hace falta Android Studio.

1. Asegúrate de que el workflow esté en `.github/workflows/build-eventflow.yml` (está en `workflows-para-mover/` y hay que moverlo).
2. Ve a la pestaña **Actions**, elige **Build EventFlow** y toca **Run workflow**.
3. Cuando termine (punto verde), entra a la ejecución y baja a **Artifacts**.
4. Descarga `EventFlow-apk`, descomprime el zip e instala `EventFlow.apk` en tu teléfono (Android te pedirá permitir "Instalar apps desconocidas").

Es un APK de **depuración**, no está firmado para Play Store.

## Compilar en tu equipo (opcional)

Requiere JDK 17, Android SDK y Gradle 8.7:

```bash
cd EventFlow
gradle assembleDebug
# APK en app/build/outputs/apk/debug/app-debug.apk
```

## Iconos propios

Mira [`PNG-ICONOS.md`](PNG-ICONOS.md) para cambiar el icono y el logotipo por tus PNG.

## Estado

> El código **no se ha compilado nunca**. El primer build en GitHub Actions lo comprobará. Si falla, copia el error del log para corregirlo.
