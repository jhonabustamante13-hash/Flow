package com.flowapps.eventflow.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowapps.eventflow.data.*
import java.time.LocalDate

@Composable
fun EventFlowApp() {
    var splash by remember { mutableStateOf(true) }
    if (splash) Splash("EventFlow", "Organiza tus celebraciones") { splash = false } else Shell()
}

@Composable
private fun Shell() {
    var tab by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<Long?>(null) }
    BackHandler(open != null) { open = null }
    GlassBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = tab to open,
                    transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(150)) },
                    label = "nav"
                ) { (t, o) ->
                    if (o != null) EventDetail(o) { open = null }
                    else when (t) {
                        0 -> HomeScreen { open = it }
                        1 -> EventsList { open = it }
                        else -> SettingsScreen("EventFlow")
                    }
                }
            }
            if (open == null) FloatingNav(
                listOf("Inicio" to Icons.Filled.Home, "Eventos" to Icons.Filled.DateRange, "Ajustes" to Icons.Filled.Settings),
                tab, { tab = it }
            )
        }
    }
}

@Composable
private fun HomeScreen(onOpen: (Long) -> Unit) {
    val ev = EventStore.events.sortedBy { it.date }
    val next = ev.firstOrNull { it.daysLeft >= 0 }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Column { Txt("EventFlow", 30.sp, true); Txt("Tu próximo evento", alpha = 0.8f) } }
        if (next == null) item {
            GlassCard(Modifier.fillMaxWidth()) { Txt("Aún no tienes eventos. Ve a la pestaña Eventos y crea el primero.") }
        } else item {
            GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(next.id) }) {
                Txt(next.name, 22.sp, true)
                Txt(daysText(next.daysLeft), 34.sp, true)
                Txt("${next.date} · ${next.time} · ${next.place}", 13.sp, alpha = 0.8f)
                Spacer(Modifier.height(10.dp))
                Txt("Preparativos", 12.sp, alpha = 0.7f)
                ProgressBar(next.progress)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Eventos", ev.size.toString(), Modifier.weight(1f))
                Stat("Gastado", money(ev.sumOf { it.spent }), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun EventsList(onOpen: (Long) -> Unit) {
    var edit by remember { mutableStateOf<Event?>(null) }
    val ev = EventStore.events.sortedBy { it.date }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Txt("Mis eventos", 28.sp, true, modifier = Modifier.weight(1f))
            GlassButton("Nuevo", icon = Icons.Filled.Add) {
                edit = Event(System.currentTimeMillis(), "", LocalDate.now().toString(), "18:00", "", 0.0)
            }
        }
        Spacer(Modifier.height(12.dp))
        if (ev.isEmpty()) Txt("Sin eventos todavía.", alpha = 0.8f)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(ev, key = { it.id }) { e ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(e.id) }) {
                    Txt(e.name, 18.sp, true)
                    Txt("${e.date} · ${e.place}", 13.sp, alpha = 0.8f)
                    Txt(daysText(e.daysLeft), 14.sp, true)
                    Spacer(Modifier.height(6.dp))
                    ProgressBar(e.progress)
                }
            }
        }
    }
    edit?.let { cur -> EventDialog(cur, { edit = null }) { EventStore.upsert(it); edit = null } }
}

@Composable
private fun EventDialog(e: Event, onDismiss: () -> Unit, onSave: (Event) -> Unit) {
    var name by remember { mutableStateOf(e.name) }
    var date by remember { mutableStateOf(e.date) }
    var time by remember { mutableStateOf(e.time) }
    var place by remember { mutableStateOf(e.place) }
    var budget by remember { mutableStateOf(if (e.budget > 0) e.budget.toString() else "") }
    var pick by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (e.name.isEmpty()) "Nuevo evento" else "Editar evento") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(name, { name = it }, "Nombre")
                OutlinedButton(onClick = { pick = true }) { Text("Fecha: $date") }
                Field(time, { time = it }, "Hora (HH:mm)")
                Field(place, { place = it }, "Ubicación")
                Field(budget, { budget = it }, "Presupuesto", number = true)
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                onSave(e.copy(name = name.trim(), date = date, time = time, place = place, budget = budget.toDoubleOrNull() ?: 0.0))
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
    if (pick) DatePick(date, { date = it }) { pick = false }
}

@Composable
private fun EventDetail(id: Long, onBack: () -> Unit) {
    val look = LocalLook.current
    val e = EventStore.events.firstOrNull { it.id == id }
    if (e == null) { LaunchedEffect(Unit) { onBack() }; return }
    var sec by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, "Volver", tint = look.text) }
            Txt(e.name, 24.sp, true, modifier = Modifier.weight(1f), maxLines = 1)
            IconButton(onClick = { edit = true }) { Icon(Icons.Filled.Edit, "Editar", tint = look.text) }
            IconButton(onClick = { del = true }) { Icon(Icons.Filled.Delete, "Eliminar", tint = look.text) }
        }
        Txt("${e.date} · ${e.time} · ${e.place}", 13.sp, alpha = 0.8f)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 10.dp)) {
            itemsIndexed(listOf("Resumen", "Invitados", "Presupuesto", "Compras", "Preparativos")) { i, s ->
                FilterChip(selected = sec == i, onClick = { sec = i }, label = { Text(s) })
            }
        }
        Box(Modifier.weight(1f)) {
            when (sec) {
                0 -> Summary(e)
                1 -> ItemsEditor(e.guests, "Nombre del invitado", true, false, { EventStore.upsert(e.copy(guests = it)) }) {
                    Txt("${e.guests.count { it.done }} de ${e.guests.size} confirmaron asistencia", bold = true)
                }
                2 -> ItemsEditor(e.expenses, "Concepto del gasto", false, true, { EventStore.upsert(e.copy(expenses = it)) }) {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Txt("Presupuesto: ${money(e.budget)}")
                        Txt("Gastado: ${money(e.spent)}")
                        Txt("Restante: ${money(e.budget - e.spent)}", 18.sp, true)
                        Spacer(Modifier.height(6.dp))
                        ProgressBar(if (e.budget > 0) (e.spent / e.budget).toFloat() else 0f)
                    }
                }
                3 -> ItemsEditor(e.shopping, "Artículo por comprar", true, true, { EventStore.upsert(e.copy(shopping = it)) }) {
                    Txt("${e.shopping.count { it.done }} de ${e.shopping.size} comprados", bold = true)
                }
                else -> ItemsEditor(e.tasks, "Preparativo o tarea", true, false, { EventStore.upsert(e.copy(tasks = it)) }) {
                    Column { Txt("Progreso: ${(e.progress * 100).toInt()}%", bold = true); ProgressBar(e.progress) }
                }
            }
        }
    }
    if (edit) EventDialog(e, { edit = false }) { EventStore.upsert(it); edit = false }
    if (del) AlertDialog(
        onDismissRequest = { del = false },
        title = { Text("¿Eliminar evento?") },
        text = { Text("Se borrarán también sus invitados, gastos, compras y preparativos.") },
        confirmButton = { TextButton(onClick = { del = false; EventStore.delete(e.id); onBack() }) { Text("Eliminar") } },
        dismissButton = { TextButton(onClick = { del = false }) { Text("Cancelar") } }
    )
}

@Composable
private fun Summary(e: Event) {
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        GlassCard(Modifier.fillMaxWidth()) { Txt(daysText(e.daysLeft), 30.sp, true); Txt("${e.date} · ${e.time}", alpha = 0.8f) }
        GlassCard(Modifier.fillMaxWidth()) {
            Txt("Preparativos ${(e.progress * 100).toInt()}%", bold = true)
            ProgressBar(e.progress)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Invitados", "${e.guests.count { it.done }}/${e.guests.size}", Modifier.weight(1f))
            Stat("Compras", "${e.shopping.count { it.done }}/${e.shopping.size}", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Gastado", money(e.spent), Modifier.weight(1f))
            Stat("Restante", money(e.budget - e.spent), Modifier.weight(1f))
        }
    }
}

@Composable
private fun ItemsEditor(
    list: List<Item>, hint: String, checkable: Boolean, amount: Boolean,
    onChange: (List<Item>) -> Unit, header: @Composable () -> Unit = {}
) {
    val look = LocalLook.current
    var t by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { header() }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Field(t, { t = it }, hint)
                if (amount) { Spacer(Modifier.height(6.dp)); Field(a, { a = it }, "Monto", number = true) }
                Spacer(Modifier.height(8.dp))
                GlassButton("Añadir", icon = Icons.Filled.Add) {
                    if (t.isNotBlank()) {
                        onChange(list + Item(System.nanoTime(), t.trim(), false, a.toDoubleOrNull() ?: 0.0))
                        t = ""; a = ""
                    }
                }
            }
        }
        items(list, key = { it.id }) { x ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (checkable) Checkbox(checked = x.done, onCheckedChange = { c -> onChange(list.map { y -> if (y.id == x.id) y.copy(done = c) else y }) })
                    Txt(x.text, modifier = Modifier.weight(1f).alpha(if (checkable && x.done) 0.55f else 1f))
                    if (amount && x.amount > 0) Txt(money(x.amount), bold = true)
                    IconButton(onClick = { onChange(list.filter { y -> y.id != x.id }) }) { Icon(Icons.Filled.Delete, "Eliminar", tint = look.text) }
                }
            }
        }
    }
}
