package com.flowapps.eventflow.data

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.temporal.ChronoUnit

data class Item(val id: Long, val text: String, val done: Boolean = false, val amount: Double = 0.0)

data class Event(
    val id: Long, val name: String, val date: String, val time: String, val place: String, val budget: Double,
    val guests: List<Item> = emptyList(), val expenses: List<Item> = emptyList(),
    val shopping: List<Item> = emptyList(), val tasks: List<Item> = emptyList()
) {
    val progress: Float get() = if (tasks.isEmpty()) 0f else tasks.count { it.done }.toFloat() / tasks.size
    val spent: Double get() = expenses.sumOf { it.amount }
    val daysLeft: Long get() = runCatching { ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(date)) }.getOrDefault(0L)
}

private fun readItems(a: JSONArray): List<Item> = (0 until a.length()).map {
    val o = a.getJSONObject(it)
    Item(o.getLong("id"), o.getString("t"), o.getBoolean("d"), o.getDouble("a"))
}

private fun writeItems(l: List<Item>): JSONArray {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("id", it.id).put("t", it.text).put("d", it.done).put("a", it.amount)) }
    return a
}

private fun Event.toJson(): JSONObject = JSONObject().put("id", id).put("n", name).put("date", date).put("time", time)
    .put("p", place).put("b", budget).put("g", writeItems(guests)).put("x", writeItems(expenses))
    .put("s", writeItems(shopping)).put("k", writeItems(tasks))

private fun readEvent(o: JSONObject) = Event(
    o.getLong("id"), o.getString("n"), o.getString("date"), o.getString("time"), o.getString("p"), o.getDouble("b"),
    readItems(o.getJSONArray("g")), readItems(o.getJSONArray("x")), readItems(o.getJSONArray("s")), readItems(o.getJSONArray("k"))
)

object EventStore {
    val events = mutableStateListOf<Event>()

    fun load() {
        events.clear()
        runCatching {
            val a = JSONArray(Prefs.getString("events", "[]"))
            for (i in 0 until a.length()) events.add(readEvent(a.getJSONObject(i)))
        }
    }

    private fun save() {
        val a = JSONArray()
        events.forEach { a.put(it.toJson()) }
        Prefs.putString("events", a.toString())
    }

    fun upsert(e: Event) {
        val i = events.indexOfFirst { it.id == e.id }
        if (i >= 0) events[i] = e else events.add(e)
        save()
    }

    fun delete(id: Long) {
        events.removeAll { it.id == id }
        save()
    }
}
