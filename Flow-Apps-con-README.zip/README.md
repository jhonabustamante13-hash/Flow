# Flow-Apps

Seis apps Android nativas e independientes (Kotlin + Jetpack Compose + Material 3). Cada carpeta tiene su propio Gradle.

## Apps

| App | Qué hace |
|---|---|
| [EventFlow](EventFlow/) | Organiza celebraciones: invitados, presupuesto, compras y preparativos |
| [TaskFlow](TaskFlow/) | Tareas con agenda, proyectos, recordatorios y estadísticas |
| [WordFlow](WordFlow/) | Diccionario en español sin conexión, ampliable con tus palabras |
| [GalleryX](GalleryX/) | Galería de fotos y vídeos con álbumes y favoritos |
| [MusicFlow](MusicFlow/) | Reproductor de música local con cola y letras |
| [CountDown](CountDown/) | Cuentas regresivas con widget y notificación |

Aviso: el código no se ha compilado nunca. El primer build en GitHub Actions lo comprobará; si falla, copia el error del log.

## Compilar
1. Mueve cada archivo de `workflows-para-mover/` a `.github/workflows/` (lápiz, cambiar nombre del archivo, Commit).
2. En **Actions** elige el workflow de la app y toca **Run workflow**.
3. Al terminar, baja a **Artifacts** y descarga `NombreApp-apk`.

## Instalar
Abre el `.apk` descargado y permite "Instalar apps desconocidas" si Android lo pide. Es un APK de depuración.

## Iconos PNG
Cada app tiene un `PNG-ICONOS.md` con la ruta donde poner tus imágenes.
